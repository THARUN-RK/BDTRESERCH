"""Apache Kafka producer and consumer integration (named "streaming" so it does not shadow the Kafka client libraries)."""
