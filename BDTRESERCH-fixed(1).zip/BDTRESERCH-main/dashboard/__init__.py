"""Streamlit analytics dashboard."""
