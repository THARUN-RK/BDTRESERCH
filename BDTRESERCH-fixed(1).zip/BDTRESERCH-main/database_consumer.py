"""Kafka -> SQLite consumer (uses confluent-kafka).

Optionally forwards every stored event to the deployed FastAPI service
(Neon PostgreSQL) so the Streamlit dashboard shows live data. Set
GAMING_API_URL, e.g. https://gaming-analytics-api.onrender.com
"""
import json
import os
import sqlite3
from datetime import datetime, timezone

import requests
from confluent_kafka import Consumer, KafkaError

BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "127.0.0.1:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "bgmi-events")
API_URL = os.getenv("GAMING_API_URL", "").rstrip("/")
DB_PATH = os.getenv("BGMI_SQLITE_DB", "gaming_analytics.db")

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS gaming_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id TEXT,
    event_type TEXT,
    score INTEGER,
    event_timestamp TEXT,
    kafka_partition INTEGER,
    kafka_offset INTEGER,
    received_at TEXT
)
"""
)
conn.commit()

consumer = Consumer(
    {
        "bootstrap.servers": BOOTSTRAP,
        "group.id": "bgmi-sqlite-group",
        "auto.offset.reset": "earliest",
        "enable.auto.commit": True,
    }
)
consumer.subscribe([TOPIC])


def forward_to_api(event, partition, offset):
    if not API_URL:
        return
    try:
        requests.post(
            f"{API_URL}/events",
            json={
                "player_id": event["player_id"],
                "event_type": event["event_type"],
                "score": event.get("score", 0),
                "event_timestamp": event.get("timestamp"),
                "kafka_partition": partition,
                "kafka_offset": offset,
            },
            timeout=30,
        ).raise_for_status()
    except requests.RequestException as error:
        print("API forward failed:", error)


print("Kafka to SQLite integration started!")
print("Storing gaming events...\n")

try:
    while True:
        message = consumer.poll(1.0)
        if message is None:
            continue
        if message.error():
            if message.error().code() == KafkaError._PARTITION_EOF:
                continue
            print("Kafka error:", message.error())
            continue
        try:
            event = json.loads(message.value().decode("utf-8"))
            player_id, event_type = event["player_id"], event["event_type"]
        except (ValueError, KeyError, UnicodeDecodeError) as error:
            print("Skipping malformed message:", error)
            continue

        cursor.execute(
            """
            INSERT INTO gaming_events
            (player_id, event_type, score, event_timestamp,
             kafka_partition, kafka_offset, received_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                player_id,
                event_type,
                event.get("score", 0),
                event.get("timestamp"),
                message.partition(),
                message.offset(),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
        forward_to_api(event, message.partition(), message.offset())
        print(f"Stored: {player_id} | {event_type} | Score: {event.get('score', 0)}")
except KeyboardInterrupt:
    print("\nDatabase consumer stopped.")
finally:
    consumer.close()
    conn.close()
