"""Simple console consumer for the BGMI-style event stream (uses confluent-kafka)."""
import json
import os

from confluent_kafka import Consumer, KafkaError

BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "127.0.0.1:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "bgmi-events")

consumer = Consumer(
    {
        "bootstrap.servers": BOOTSTRAP,
        "group.id": "bgmi-analytics-group",
        "auto.offset.reset": "latest",
        "enable.auto.commit": True,
    }
)
consumer.subscribe([TOPIC])

print("BGMI Kafka Consumer Started...")
print("Waiting for gaming events...\n")

try:
    while True:
        message = consumer.poll(1.0)
        if message is None:
            continue
        if message.error():
            if message.error().code() == KafkaError._PARTITION_EOF:
                continue
            print("Kafka error:", message.error())
            continue
        try:
            event = json.loads(message.value().decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as error:
            print("Skipping malformed message:", error)
            continue

        print("--------------------------------")
        print("PLAYER ID :", event.get("player_id"))
        print("EVENT     :", event.get("event_type"))
        print("SCORE     :", event.get("score"))
        print("TIMESTAMP :", event.get("timestamp"))
        print("PARTITION :", message.partition())
        print("--------------------------------")
except KeyboardInterrupt:
    print("\nConsumer stopped.")
finally:
    consumer.close()
