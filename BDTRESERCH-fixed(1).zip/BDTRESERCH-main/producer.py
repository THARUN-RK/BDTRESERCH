"""Simple continuous BGMI-style event producer (uses confluent-kafka)."""
import json
import os
import random
import time
from datetime import datetime, timezone

from confluent_kafka import Producer

BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "127.0.0.1:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "bgmi-events")
PLAYERS = ["Player101", "Player102", "Player103", "Player104"]
EVENT_TYPES = ["kill", "death", "match_start", "match_end", "loot"]

producer = Producer({"bootstrap.servers": BOOTSTRAP})


def on_delivery(error, message):
    if error is not None:
        print("Delivery failed:", error)


print("BGMI Gaming Event Generator Started...")

try:
    while True:
        event = {
            "player_id": random.choice(PLAYERS),
            "event_type": random.choice(EVENT_TYPES),
            "score": random.randint(0, 100),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        producer.produce(
            TOPIC,
            key=event["player_id"].encode("utf-8"),
            value=json.dumps(event).encode("utf-8"),
            on_delivery=on_delivery,
        )
        producer.poll(0)
        print("Event sent:", event)
        time.sleep(1)
except KeyboardInterrupt:
    print("Producer stopped.")
finally:
    producer.flush(10)
